package com.capgemini.zuulservicebank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZuulServiceBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZuulServiceBankApplication.class, args);
	}

}

